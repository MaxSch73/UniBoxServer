import validator from 'is-my-json-valid';
import { dbGetStudents, dbGetStudent, dbDelStudent, dbPostStudent, dbPatchStudent } from '../models/student.js';
// first_name, last_name, email, birthday, address, currentOrEx;
const validate = validator({
  required: true,
  type: 'object',
  properties: {
    first_name: {
      required: true,
      type: 'string',
    },
    last_name: {
      required: true,
      type: 'string',
    },
    email: {
      required: true,
      type: 'string',
    },
    birthday: {
      required: true,
      type: 'string',
    },
    address: {
      required: true,
      type: 'string',
    },
    currentOrEx: {
      required: true,
      type: 'boolean',
    },
  },
});

const getStudents = async (req, res) => res.status(200).json(await dbGetStudents());

const getStudent = async (req, res) => {
  const { id } = req.params;
  const student = await dbGetStudent(id);
  if (!student) return res.status(404).send('Ressource not found');
  return res.status(200).json(student);
};

const delStudent = async (req, res) => {
  const { id } = req.params;
  const student = await dbGetStudent(id);
  if (!student) return res.status(404).send('Ressource not found');
  await dbDelStudent(id);
  return res.status(200).end();
};

const postStudent = async (req, res) => {
  if (!validate(req.body)) return res.status(400).json(validate.errors);
  const student = await dbPostStudent(req.body);
  return res.status(201).json(student);
};

const patchStudent = async (req, res) => { n
  const { id } = req.params;
  let student = await dbGetStudent(id);
  if (!student) return res.status(404).send('Ressource not found');
  // student = await dbPatcSstudent(id,req.body.title);
  return res.status(200).json(student);
};

// const putStudent = async (req, res) => {
//   const { id } = req.params;
//   let student = await dbGetStudent(id);
//   if (!validate(req.body)) return res.status(400).json(validate.errors);
//   student = await dbPutStudent(id,req.body);
//   return res.status(201).json(student);
// };
export { getStudents, getStudent, delStudent, postStudent, patchStudent };
