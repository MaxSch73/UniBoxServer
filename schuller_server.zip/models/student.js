import { pool, query } from '../db/index.js';

const dbGetStudents = async () => {
  const { rows } = await query('SELECT * FROM student order by student_id asc');
  return rows;
};

const dbGetStudent = async (id) => {
  const { rows } = await query('SELECT * FROM student WHERE student_id=$1', [id]);
  return rows[0];
};
const dbDelStudent = (id) => query('DELETE FROM student WHERE student_id=$1', [id]);

const dbPostStudent = async ({ first_name, last_name, email, birthday, address, currentOrEx,enrollment_id }) => {
  const { rows } = await query(
    'INSERT INTO student(first_name, last_name, email, birthday, address, currentOrEx,enrollment_id) values ($1, $2, $3, $4, $5, $6) returning *',
    [first_name, last_name, email, birthday, address, currentOrEx],
  );
  return rows[0];
};

const dbPatchStudent = async (id, title) => {
  const client = await pool.connect(); // get DB client
  try {
    await client.query('BEGIN');
    const { rows } = await query('SELECT * FROM student WHERE student_id=$1', [id]);
    if (!rows[0]) return null;
    const result = await query('UPDATE student SET email = $1 WHERE student_id = $2 returning *', [
      email,
      id,
    ]);
    await client.query('COMMIT');
    return result.rows[0];
  } catch (error) {
    console.error(error);
    await client.query('ROLLBACK');
  } finally {
    client.release();
  }
};

// const dbPutStudent = async (id, { title, letter, image, admission, description }) => {
//   const client = await pool.connect(); // get DB client
//   try {
//     await client.query('BEGIN');
//     const { rows } = await query(
//       'UPDATE sights SET title = $2, letter = $1, image = $3, admission = $4, description = $5 where id=$6 returning *',
//       [letter, title, image, admission, description, id],
//     );
//     await client.query('COMMIT');
//     return rows[0];
//   } catch (error) {
//     console.error(error);
//     await client.query('ROLLBACK');
//   } finally {
//     client.release();
//   }
// };

export { dbGetStudents, dbGetStudent, dbDelStudent, dbPostStudent, dbPatchStudent };
