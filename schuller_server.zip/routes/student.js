import express from 'express';
import asyncHandler from 'express-async-handler';


import { getStudents, getStudent, delStudent, postStudent, patchStudent } from '../controllers/student.js';

const router = express.Router();

router.get('/', asyncHandler(getStudents));
router.get('/:id', asyncHandler(getStudent));
router.delete('/:id', asyncHandler(delStudent));
router.post('/', asyncHandler(postStudent));
router.patch('/:id', asyncHandler(patchStudent));
// router.put('/:id', asyncHandler(putStudent));
export default router;
